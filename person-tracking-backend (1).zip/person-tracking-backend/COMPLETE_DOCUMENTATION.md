# Person Tracking System - Complete Documentation

## 📖 Table of Contents
1. [What is This System?](#what-is-this-system)
2. [Why Do We Need It?](#why-do-we-need-it)
3. [How Does It Work?](#how-does-it-work)
4. [System Architecture](#system-architecture)
5. [Database Design](#database-design)
6. [API Endpoints Explained](#api-endpoints-explained)
7. [User Roles & Permissions](#user-roles--permissions)
8. [Complete Workflow Examples](#complete-workflow-examples)
9. [Technical Implementation](#technical-implementation)
10. [How to Use This System](#how-to-use-this-system)

---

## What is This System?

The **Person Tracking System** is a comprehensive backend application designed to track individuals and their complete life history including:
- **Personal Information** - Name, date of birth, contacts, family details
- **Education History** - All schools/colleges attended from primary to university
- **Employment History** - Complete work experience and career progression
- **Birth Information** - Which hospital they were born in
- **Current Location** - Which jurisdiction (city/municipality) they live in
- **Contact Information** - Multiple phone numbers (mobile, home, office)

### Real-World Use Cases:

**1. Government Census System**
- Track all citizens in a jurisdiction
- Know where people were born, studied, and work
- Understand population distribution across cities

**2. HR Background Verification**
- Verify candidate's education claims
- Check employment history
- Contact previous employers for references

**3. University Alumni Network**
- Track all graduates from a university
- See where alumni are working now
- Connect students with alumni in specific companies

**4. Job Portal Backend**
- Store candidate profiles
- Track their education and experience
- Link candidates to companies and schools

---

## Why Do We Need It?

### Problems This System Solves:

**1. Scattered Information**
- ❌ **Problem**: Person's education in one file, employment in another, contacts somewhere else
- ✅ **Solution**: Everything in one centralized database

**2. No Historical Tracking**
- ❌ **Problem**: Only know current job, not complete career path
- ✅ **Solution**: Complete history of all schools attended and companies worked at

**3. Multiple Contact Numbers**
- ❌ **Problem**: Person has mobile, home, office numbers - can't store all
- ✅ **Solution**: Unlimited contact numbers per person with types

**4. No Relationships**
- ❌ **Problem**: Can't easily find "all people who studied at TU" or "all employees of Company X"
- ✅ **Solution**: Many-to-many relationships enable complex queries

**5. Manual Verification**
- ❌ **Problem**: Calling each school/company to verify manually
- ✅ **Solution**: All data in system, quick lookups

---

## How Does It Work?

### Simple Flow:

```
1. CREATE ORGANIZATIONS
   (Jurisdictions, Schools, Companies, Hospitals)
   ↓
2. CREATE PERSON RECORD
   (Basic info: name, DOB, etc.)
   ↓
3. ADD CONTACT NUMBERS
   (Mobile, Home, Office)
   ↓
4. ADD EDUCATION HISTORY
   (All schools/colleges attended)
   ↓
5. ADD EMPLOYMENT HISTORY
   (All companies worked at)
   ↓
6. VIEW COMPLETE PROFILE
   (Everything in one place)
```

### Example Scenario:

**Track "Ram Kumar Sharma":**

1. **Create Jurisdictions**: Kathmandu, Lalitpur
2. **Create School**: Budhanilkantha School, Tribhuvan University
3. **Create Company**: Tech Solutions Nepal
4. **Create Hospital**: Bir Hospital
5. **Create Person**: Ram Kumar Sharma
   - Born: 1995-05-15
   - Birth Hospital: Bir Hospital
   - Lives in: Kathmandu
6. **Add Contacts**: 
   - 9841234567 (Mobile)
   - 01-4567890 (Home)
7. **Add Education**:
   - Budhanilkantha School (2005-2015)
   - Tribhuvan University (2015-2019) - BCA
8. **Add Employment**:
   - Tech Solutions Nepal (2020-present) - Developer

**Now you can:**
- Get Ram's complete profile
- Find all TU alumni
- Find all employees of Tech Solutions
- Find all people born at Bir Hospital
- Find all people living in Kathmandu

---

## System Architecture

### Three-Layer Architecture:

```
┌─────────────────────────────────────────┐
│         CLIENT LAYER                    │
│  (Postman, Web App, Mobile App, etc.)   │
└─────────────────┬───────────────────────┘
                  │ HTTP REST API
                  │ (JSON format)
                  ↓
┌─────────────────────────────────────────┐
│       APPLICATION LAYER (Backend)       │
│                                         │
│  ┌──────────────────────────────────┐  │
│  │   Routes (API Endpoints)         │  │
│  │   /api/persons, /api/history     │  │
│  └──────────────┬───────────────────┘  │
│                 ↓                       │
│  ┌──────────────────────────────────┐  │
│  │   Controllers (Business Logic)   │  │
│  │   Process requests, validation   │  │
│  └──────────────┬───────────────────┘  │
│                 ↓                       │
│  ┌──────────────────────────────────┐  │
│  │   Middleware (Auth, Validation)  │  │
│  │   Check JWT, validate input      │  │
│  └──────────────────────────────────┘  │
└─────────────────┬───────────────────────┘
                  │ SQL Queries
                  ↓
┌─────────────────────────────────────────┐
│        DATABASE LAYER (MySQL)           │
│  10 Tables with Relationships           │
│  Views, Procedures, Functions, Triggers │
└─────────────────────────────────────────┘
```

### Components Breakdown:

**1. Routes** (`routes/` folder)
- Define URL endpoints
- Map URLs to controller functions
- Example: `GET /api/persons/1` → `personController.getPersonById()`

**2. Controllers** (`controllers/` folder)
- Business logic for each operation
- Validate input
- Query database
- Send response
- Example: `personController.js` handles all person operations

**3. Middleware** (`middleware/` folder)
- `auth.js` - Checks if user is logged in (JWT verification)
- `upload.js` - Handles file uploads (if needed)

**4. Database Config** (`config/` folder)
- Connects to MySQL
- Manages connection pool

**5. Database Schema** (`database/` folder)
- SQL file that creates all tables
- Inserts sample data
- Creates views, procedures, functions

---

## Database Design

### 10 Main Tables:

#### 1. **Jurisdiction** - Cities/Municipalities
```
Purpose: Store administrative regions

Columns:
- jurisdiction_id (PK) - Unique ID
- jurisdiction_name - e.g., "Kathmandu Metropolitan City"
- mayor - Current mayor's name
- vice_mayor - Vice mayor's name
- no_of_districts - Number of districts in jurisdiction

Example Data:
ID | Name                           | Mayor       | Districts
1  | Kathmandu Metropolitan City    | Balen Shah  | 32
2  | Lalitpur Metropolitan City     | Chiribabu   | 29
```

**Why?** Group people by where they live, work, or study.

---

#### 2. **Hospital** - Medical Facilities
```
Purpose: Track hospitals where people were born

Columns:
- hospital_id (PK)
- hospital_name - e.g., "Bir Hospital"
- hospital_address - Location
- hospital_estd - When hospital was established
- hospital_director - Current director
- jurisdiction_id (FK) - Which city it's in

Example Data:
ID | Name         | Address           | Jurisdiction
1  | Bir Hospital | Tundikhel, KTM    | Kathmandu
2  | Patan Hospital| Lagankhel, Patan | Lalitpur
```

**Why?** Know where people were born for records/verification.

---

#### 3. **School** - Educational Institutions
```
Purpose: Store all schools, colleges, universities

Columns:
- school_id (PK)
- school_name - e.g., "Tribhuvan University"
- school_address - Location
- jurisdiction_id (FK) - Which city it's in

Example Data:
ID | Name                    | Address        | Jurisdiction
1  | Budhanilkantha School   | Budhanilkantha | Kathmandu
5  | Tribhuvan University    | Kirtipur       | Kathmandu
```

**Why?** Track where people studied for education verification.

---

#### 4. **Company** - Organizations/Employers
```
Purpose: Store companies where people work

Columns:
- company_id (PK)
- company_name - e.g., "Tech Solutions Nepal"
- company_type - "IT Services", "Trading", etc.
- company_estd_date - When company was founded
- company_value - Company valuation
- company_main_branch_jurisdiction_id (FK) - HQ location
- current_branch_jurisdiction_id (FK) - Current branch location

Example Data:
ID | Name                | Type        | HQ        | Value
1  | Tech Solutions Nepal| IT Services | Kathmandu | 50M
2  | Himalayan Trading   | Trading     | Kathmandu | 100M
```

**Why?** Track employment, verify work history.

---

#### 5. **Person** - Main Individual Records
```
Purpose: Core table storing person information

Columns:
- id (PK) - Unique person ID
- name - Full name
- dob - Date of birth
- contact - Primary contact number
- no_of_family_members - Family size
- school_id (FK) - Current/latest school
- company_id (FK) - Current/latest company
- schooling_history - Text summary
- working_history - Text summary
- jurisdiction_id (FK) - Where they live now
- birth_hospital_id (FK) - Where they were born

Example Data:
ID | Name              | DOB        | Contact      | Lives In
1  | Ram Kumar Sharma  | 1995-05-15 | 9841234567   | Kathmandu
2  | Sita Kumari Thapa | 1998-03-20 | 9851234567   | Lalitpur
```

**Why?** Central record for each individual.

---

#### 6. **Login** - User Authentication
```
Purpose: Users who can access the system

Columns:
- login_id (PK)
- username - Login username
- email - Email address
- password_hash - Encrypted password
- role - admin, hr, verifier, user

Example Data:
ID | Username | Email             | Role
1  | admin    | admin@system.com  | admin
2  | hr_user  | hr@system.com     | hr
```

**Why?** Control who can access and modify data.

---

#### 7. **Person_School** - Education History (Junction Table)
```
Purpose: Track all schools a person attended (many-to-many)

Columns:
- id (PK)
- person_id (FK) - Which person
- school_id (FK) - Which school
- start_date - When they started
- end_date - When they finished
- notes - Additional info (degree, grade, etc.)

Example Data:
ID | Person          | School                | Dates        | Notes
1  | Ram (ID=1)      | Budhanilkantha (ID=1) | 2005-2015    | SLC
2  | Ram (ID=1)      | TU (ID=5)             | 2015-2019    | BCA

This shows Ram studied at 2 schools!
```

**Why Many-to-Many?**
- One person can study at multiple schools ✓
- One school can have multiple students ✓

---

#### 8. **Person_Company** - Employment History (Junction Table)
```
Purpose: Track all companies a person worked at (many-to-many)

Columns:
- id (PK)
- person_id (FK) - Which person
- company_id (FK) - Which company
- start_date - When they started
- end_date - When they left (NULL = current)
- position - Job title

Example Data:
ID | Person     | Company            | Dates        | Position
1  | Ram (ID=1) | Tech Solutions (1) | 2020-present | Developer

end_date = NULL means still working there!
```

**Why Many-to-Many?**
- One person can work at multiple companies (career changes) ✓
- One company can have multiple employees ✓

---

#### 9. **Person_Contact** - Contact Numbers
```
Purpose: Store multiple contact numbers for each person

Columns:
- id (PK)
- person_id (FK) - Which person
- contact_number - Phone number
- type - Mobile, Home, Office, Emergency, etc.

Example Data:
ID | Person     | Number      | Type
1  | Ram (ID=1) | 9841234567  | Mobile
2  | Ram (ID=1) | 01-4567890  | Home
3  | Ram (ID=1) | 01-5555555  | Office

Ram has 3 different numbers!
```

**Why One-to-Many?**
- One person can have multiple contacts ✓
- Each contact belongs to one person ✓

---

#### 10. **Data_logs** - Activity Logging
```
Purpose: Track all system activities for audit

Columns:
- log_id (PK)
- log_text - What happened
- log_timestamp - When it happened
- log_code_string - Event type code
- status_code - HTTP status (200, 201, etc.)
- source - Who/what triggered it

Example Data:
ID | Text                      | Timestamp           | Code
1  | Person created: Ram       | 2026-02-22 10:00:00 | PERSON_CREATE
2  | Person updated: Ram       | 2026-02-22 11:30:00 | PERSON_UPDATE
```

**Why?** Know who did what and when for security/debugging.

---

### Database Relationships Visualized:

```
Jurisdiction (1) ────< (Many) Hospital
Jurisdiction (1) ────< (Many) School  
Jurisdiction (1) ────< (Many) Company (main branch)
Jurisdiction (1) ────< (Many) Company (current branch)
Jurisdiction (1) ────< (Many) Person (current residence)

Hospital (1) ────< (Many) Person (birth hospital)

Person (Many) >────< (Many) School
      └─── through Person_School junction table

Person (Many) >────< (Many) Company
      └─── through Person_Company junction table

Person (1) ────< (Many) Person_Contact
```

**Key:**
- `(1) ────< (Many)` = One-to-Many
- `(Many) >────< (Many)` = Many-to-Many (requires junction table)

---

## API Endpoints Explained

### What is an API Endpoint?

An endpoint is like a specific service window at a government office:
- Window 1: Register new person
- Window 2: Get person details
- Window 3: Update person info
- Window 4: Delete person record

Each window (endpoint) does one specific thing.

### Endpoint Format:

```
METHOD   /api/resource/action
POST     /api/persons

METHOD = What to do? (POST=Create, GET=Read, PUT=Update, DELETE=Delete)
/api/resource = What thing? (persons, schools, companies)
/action = Specific action (optional)
```

---

### All 35+ Endpoints by Category:

#### **AUTHENTICATION (3 Endpoints)**

**1. Register New User**
```
POST /api/auth/register

What: Create new user account
Who: Anyone (first-time registration)
Input: username, email, password, role

Example Request:
{
  "username": "john_hr",
  "email": "john@company.com",
  "password": "secure123",
  "role": "hr"
}

Example Response:
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "id": 4,
    "username": "john_hr",
    "role": "hr"
  }
}
```

**2. Login**
```
POST /api/auth/login

What: Login to get access token
Who: Users with accounts
Input: email, password

Example Request:
{
  "email": "admin@system.com",
  "password": "admin123"
}

Example Response:
{
  "success": true,
  "data": {
    "token": "eyJhbGc..." ← Use this token in all future requests!
    "user": {
      "id": 1,
      "username": "admin",
      "role": "admin"
    }
  }
}

IMPORTANT: Save the token! You need it for all other requests.
```

**3. Get My Profile**
```
GET /api/auth/profile
Headers: Authorization: Bearer <token>

What: See your own account info
Who: Logged-in users

Example Response:
{
  "success": true,
  "data": {
    "login_id": 1,
    "username": "admin",
    "email": "admin@system.com",
    "role": "admin"
  }
}
```

---

#### **PERSON MANAGEMENT (6 Endpoints)**

**4. Create Person**
```
POST /api/persons
Headers: Authorization: Bearer <token>

What: Register a new person in system
Who: Admin, HR

Example Request:
{
  "name": "Ram Kumar Sharma",
  "dob": "1995-05-15",
  "contact": 9841234567,
  "no_of_family_members": 5,
  "school_id": 1,
  "company_id": 1,
  "jurisdiction_id": 1,
  "birth_hospital_id": 1
}

Example Response:
{
  "success": true,
  "message": "Person created successfully",
  "data": {
    "id": 5,  ← New person ID
    "name": "Ram Kumar Sharma"
  }
}
```

**5. Get All Persons**
```
GET /api/persons?page=1&limit=10&search=Ram
Headers: Authorization: Bearer <token>

What: List all persons (with pagination and search)
Who: All logged-in users

Query Parameters:
- page: Page number (default 1)
- limit: Items per page (default 10)
- search: Search by name

Example Response:
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Ram Kumar Sharma",
      "dob": "1995-05-15",
      "contact": 9841234567,
      "jurisdiction_name": "Kathmandu Metropolitan City",
      "birth_hospital": "Bir Hospital",
      "current_school": "Budhanilkantha School",
      "current_company": "Tech Solutions Nepal"
    },
    // ... more persons
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 50,
    "totalPages": 5
  }
}
```

**6. Get Person by ID**
```
GET /api/persons/1
Headers: Authorization: Bearer <token>

What: Get complete profile for one person
Who: All logged-in users

Returns EVERYTHING:
- Basic info (name, DOB, etc.)
- Current jurisdiction, school, company, birth hospital
- ALL contact numbers
- COMPLETE education history
- COMPLETE employment history

Example Response:
{
  "success": true,
  "data": {
    "id": 1,
    "name": "Ram Kumar Sharma",
    "dob": "1995-05-15",
    "contact": 9841234567,
    "no_of_family_members": 5,
    "jurisdiction_name": "Kathmandu Metropolitan City",
    "birth_hospital": "Bir Hospital",
    "current_school": "Budhanilkantha School",
    "current_company": "Tech Solutions Nepal",
    
    "contacts": [
      {"id": 1, "contact_number": "9841234567", "type": "Mobile"},
      {"id": 2, "contact_number": "01-4567890", "type": "Home"}
    ],
    
    "education_history": [
      {
        "id": 2,
        "school_name": "Tribhuvan University",
        "start_date": "2015-04-01",
        "end_date": "2019-03-31",
        "years_attended": 4,
        "notes": "Bachelor in Computer Application"
      },
      {
        "id": 1,
        "school_name": "Budhanilkantha School",
        "start_date": "2005-04-01",
        "end_date": "2015-03-31",
        "years_attended": 10,
        "notes": "Completed SLC"
      }
    ],
    
    "employment_history": [
      {
        "id": 1,
        "company_name": "Tech Solutions Nepal Pvt. Ltd.",
        "company_type": "IT Services",
        "position": "Software Developer",
        "start_date": "2020-01-15",
        "end_date": null,
        "employment_status": "Current",
        "years_worked": 6
      }
    ]
  }
}
```

**7. Update Person**
```
PUT /api/persons/1
Headers: Authorization: Bearer <token>

What: Update person's basic information
Who: Admin, HR

Same input as Create Person
```

**8. Delete Person**
```
DELETE /api/persons/1
Headers: Authorization: Bearer <token>

What: Remove person from system
Who: Admin only

Response:
{
  "success": true,
  "message": "Person deleted successfully"
}
```

**9. Get Person Profile (Stored Procedure)**
```
GET /api/persons/1/profile
Headers: Authorization: Bearer <token>

What: Same as Get Person by ID, but uses database stored procedure
Who: All logged-in users
```

---

#### **EDUCATION HISTORY (4 Endpoints)**

**10. Add Education Record**
```
POST /api/history/education
Headers: Authorization: Bearer <token>

What: Add a school/college to person's education history
Who: Admin, HR

Example Request:
{
  "person_id": 1,
  "school_id": 5,
  "start_date": "2015-04-01",
  "end_date": "2019-03-31",
  "notes": "Bachelor in Computer Application"
}

Response:
{
  "success": true,
  "message": "Education record added successfully",
  "data": {"id": 3}
}
```

**11. Get Education by Person**
```
GET /api/history/education/person/1
Headers: Authorization: Bearer <token>

What: Get all schools/colleges a person attended
Who: All logged-in users

Response shows:
- All schools attended
- Dates (start/end)
- How many years at each school (auto-calculated)
- Notes (degree, achievements, etc.)
```

**12. Update Education Record**
```
PUT /api/history/education/3
Headers: Authorization: Bearer <token>

What: Update education details
Who: Admin, HR
```

**13. Delete Education Record**
```
DELETE /api/history/education/3
Headers: Authorization: Bearer <token>

What: Remove education record
Who: Admin, HR
```

---

#### **EMPLOYMENT HISTORY (4 Endpoints)**

**14. Add Employment Record**
```
POST /api/history/employment
Headers: Authorization: Bearer <token>

What: Add a job to person's employment history
Who: Admin, HR

Example Request:
{
  "person_id": 1,
  "company_id": 1,
  "start_date": "2020-01-15",
  "end_date": null,  ← NULL means current job
  "position": "Software Developer"
}

Response:
{
  "success": true,
  "message": "Employment record added successfully",
  "data": {"id": 2}
}
```

**15. Get Employment by Person**
```
GET /api/history/employment/person/1
Headers: Authorization: Bearer <token>

What: Get all jobs a person has had
Who: All logged-in users

Response shows:
- All companies worked at
- Positions held
- Dates (start/end)
- Employment status (Current or Former)
- How many years at each company (auto-calculated)
```

**16. Update Employment Record**
```
PUT /api/history/employment/2
Headers: Authorization: Bearer <token>

What: Update job details (e.g., add end date when person leaves)
Who: Admin, HR
```

**17. Delete Employment Record**
```
DELETE /api/history/employment/2
Headers: Authorization: Bearer <token>

What: Remove employment record
Who: Admin, HR
```

---

#### **CONTACT MANAGEMENT (4 Endpoints)**

**18. Add Contact Number**
```
POST /api/history/contact
Headers: Authorization: Bearer <token>

What: Add a contact number to person
Who: Admin, HR

Example Request:
{
  "person_id": 1,
  "contact_number": "9841234567",
  "type": "Mobile"
}

Types: Mobile, Home, Office, Emergency, etc.
```

**19. Get Contacts by Person**
```
GET /api/history/contact/person/1
Headers: Authorization: Bearer <token>

What: Get all contact numbers for a person
Who: All logged-in users
```

**20. Update Contact**
```
PUT /api/history/contact/1
Headers: Authorization: Bearer <token>

What: Update contact number or type
Who: Admin, HR
```

**21. Delete Contact**
```
DELETE /api/history/contact/1
Headers: Authorization: Bearer <token>

What: Remove contact number
Who: Admin, HR
```

---

#### **ORGANIZATION MANAGEMENT (9 Endpoints)**

**22. Create Jurisdiction**
```
POST /api/organizations/jurisdictions
Headers: Authorization: Bearer <token>

What: Add a new city/municipality
Who: Admin only

Example:
{
  "jurisdiction_name": "Pokhara Metropolitan City",
  "mayor": "Dhanraj Acharya",
  "vice_mayor": "Kopila Ranabhat",
  "no_of_districts": 33
}
```

**23. Get All Jurisdictions**
```
GET /api/organizations/jurisdictions
Headers: Authorization: Bearer <token>

What: List all cities/municipalities
Who: All logged-in users
```

**24. Create School**
```
POST /api/organizations/schools
Headers: Authorization: Bearer <token>

What: Add a new school/college/university
Who: Admin, HR

Example:
{
  "school_name": "Kathmandu University",
  "school_address": "Dhulikhel, Kavre",
  "jurisdiction_id": 1
}
```

**25. Get All Schools**
```
GET /api/organizations/schools
Headers: Authorization: Bearer <token>

What: List all educational institutions
Who: All logged-in users
```

**26. Create Company**
```
POST /api/organizations/companies
Headers: Authorization: Bearer <token>

What: Add a new company/organization
Who: Admin, HR

Example:
{
  "company_name": "Nepal Bank Limited",
  "company_type": "Banking",
  "company_estd_date": "1937-11-15",
  "company_value": "NPR 200,000,000",
  "company_main_branch_jurisdiction_id": 1,
  "current_branch_jurisdiction_id": 1
}
```

**27. Get All Companies**
```
GET /api/organizations/companies
Headers: Authorization: Bearer <token>

What: List all companies
Who: All logged-in users
```

**28. Create Hospital**
```
POST /api/organizations/hospitals
Headers: Authorization: Bearer <token>

What: Add a new hospital
Who: Admin, HR

Example:
{
  "hospital_name": "Kathmandu Medical College",
  "hospital_address": "Sinamangal, Kathmandu",
  "hospital_estd": "1997-01-01 00:00:00",
  "hospital_director": "Dr. Ram Shrestha",
  "jurisdiction_id": 1
}
```

**29. Get All Hospitals**
```
GET /api/organizations/hospitals
Headers: Authorization: Bearer <token>

What: List all hospitals
Who: All logged-in users
```

**30. Get Statistics**
```
GET /api/organizations/statistics
Headers: Authorization: Bearer <token>

What: Get system-wide statistics
Who: All logged-in users

Example Response:
{
  "success": true,
  "data": {
    "total_persons": 150,
    "total_schools": 25,
    "total_companies": 40,
    "total_hospitals": 12,
    "total_jurisdictions": 8,
    "total_education_records": 450,
    "total_employment_records": 320
  }
}
```

---

## User Roles & Permissions

### Four User Types:

#### 1. **Admin** (Full System Access)
```
Can do EVERYTHING:
✅ Manage users
✅ Create/edit/delete persons
✅ Manage education/employment/contacts
✅ Create organizations (jurisdictions, schools, companies, hospitals)
✅ View all data
✅ Delete anything

Use Case: System administrator, Database manager
```

#### 2. **HR** (Human Resources)
```
Can do MOST things:
✅ Create/edit persons (not delete)
✅ Manage education/employment/contacts
✅ Create schools/companies/hospitals (not jurisdictions)
✅ View all data
❌ Cannot delete persons
❌ Cannot create jurisdictions

Use Case: HR department staff who process employee data
```

#### 3. **Verifier** (Read-Only + Verification)
```
Can VIEW but NOT create/edit:
✅ View all persons and their complete profiles
✅ View all organizations
✅ View statistics
❌ Cannot create/edit/delete anything

Use Case: Background verification team, auditors
```

#### 4. **User** (Basic Access)
```
Can VIEW limited data:
✅ View persons list
✅ View organizations
✅ View statistics
❌ Cannot create/edit/delete

Use Case: General staff with view-only access
```

### Permission Matrix:

| Action | Admin | HR | Verifier | User |
|--------|-------|-----|----------|------|
| **PERSONS** |
| Create Person | ✅ | ✅ | ❌ | ❌ |
| View Persons | ✅ | ✅ | ✅ | ✅ |
| Edit Person | ✅ | ✅ | ❌ | ❌ |
| Delete Person | ✅ | ❌ | ❌ | ❌ |
| **EDUCATION/EMPLOYMENT** |
| Add Education/Employment | ✅ | ✅ | ❌ | ❌ |
| View History | ✅ | ✅ | ✅ | ✅ |
| Edit History | ✅ | ✅ | ❌ | ❌ |
| Delete History | ✅ | ✅ | ❌ | ❌ |
| **CONTACTS** |
| Add Contact | ✅ | ✅ | ❌ | ❌ |
| View Contacts | ✅ | ✅ | ✅ | ✅ |
| Edit Contact | ✅ | ✅ | ❌ | ❌ |
| Delete Contact | ✅ | ✅ | ❌ | ❌ |
| **ORGANIZATIONS** |
| Create Jurisdiction | ✅ | ❌ | ❌ | ❌ |
| Create School/Company/Hospital | ✅ | ✅ | ❌ | ❌ |
| View Organizations | ✅ | ✅ | ✅ | ✅ |

---

## Complete Workflow Examples

### Example 1: Government Census System

**Scenario**: Track all citizens in Kathmandu

**Step 1: Setup (Admin)**
```
1. Login as admin
2. Create Jurisdiction: Kathmandu Metropolitan City
3. Create Schools: Multiple schools in Kathmandu
4. Create Companies: Major employers in Kathmandu
5. Create Hospitals: Maternity hospitals
```

**Step 2: Data Entry (HR Staff)**
```
For each citizen:
1. Create Person record
2. Add multiple contact numbers
3. Add education history (all schools attended)
4. Add employment history (all jobs)
```

**Step 3: Analysis (Admin)**
```
Queries:
- How many people live in Kathmandu? (filter by jurisdiction)
- How many studied at TU? (filter by school in education history)
- How many work at Tech Solutions? (filter by company in employment)
- Age distribution? (calculate from DOB)
```

---

### Example 2: University Alumni Tracking

**Scenario**: Track all Tribhuvan University graduates

**Step 1: Initial Setup**
```
1. Create Jurisdiction: Kathmandu
2. Create School: Tribhuvan University
3. Create Companies: Where alumni work
```

**Step 2: Add Alumni**
```
For each graduate:
1. Create Person
2. Add education: TU (start: 2015, end: 2019, notes: "BCA")
3. Add current employment
4. Add contact info
```

**Step 3: Alumni Network**
```
Find TU alumni at specific company:
- Query education_history for school_id = TU
- Cross-reference with employment_history
- Filter by company

Result: "Ram and Sita both studied at TU and work at Tech Solutions"
```

---

### Example 3: HR Background Verification

**Scenario**: Verify new hire "Ram Kumar Sharma"

**Day 1: HR Receives Application**
```
POST /api/persons
{
  "name": "Ram Kumar Sharma",
  "dob": "1995-05-15",
  "contact": 9841234567
}
→ Person created, ID: 10
```

**Day 2: HR Adds Claimed Education**
```
POST /api/history/education
{
  "person_id": 10,
  "school_id": 5,  // Tribhuvan University
  "start_date": "2015-04-01",
  "end_date": "2019-03-31",
  "notes": "Claims: Bachelor in Computer Application"
}
```

**Day 3: HR Adds Claimed Employment**
```
POST /api/history/employment
{
  "person_id": 10,
  "company_id": 3,  // Previous company
  "start_date": "2019-06-01",
  "end_date": "2024-12-31",
  "position": "Claims: Junior Developer"
}
```

**Day 4: Verifier Checks**
```
1. Login as verifier
2. GET /api/persons/10  // View complete profile
3. Call TU registry: "Did Ram study here 2015-2019?" → Yes ✓
4. Call previous company: "Did Ram work there as Junior Dev?" → Yes ✓
5. Update notes: "Verified: Education ✓, Employment ✓"
```

**Day 5: Hiring Decision**
```
HR reviews verified profile
All claims verified → Approve hiring
```

---

## Technical Implementation

### 1. Authentication Flow

```
User Registration:
1. User sends: username, email, password
2. System hashes password with bcrypt
3. Stores in Login table
4. Returns: User created

User Login:
1. User sends: email, password
2. System finds user in Login table
3. Compares password with stored hash using bcrypt
4. If match: Generate JWT token
5. Token contains: user ID, role, expiration (7 days)
6. Returns: token

Using Token:
1. User includes token in every request: Authorization: Bearer <token>
2. Middleware verifies token signature
3. Extracts user info from token
4. Checks if user has permission for this action
5. If authorized: Process request
6. If not: Return 403 Forbidden
```

**JWT Token Structure:**
```javascript
{
  "id": 1,          // User ID
  "username": "admin",
  "role": "admin",
  "iat": 1708617600,  // Issued at timestamp
  "exp": 1709222400   // Expires in 7 days
}
```

---

### 2. Many-to-Many Relationships

**Problem**: How to track that Ram studied at multiple schools?

**Solution**: Junction Table (Person_School)

```
Person Table:
ID | Name
1  | Ram Kumar Sharma

School Table:
ID | Name
1  | Budhanilkantha School
5  | Tribhuvan University

Person_School Table (Junction):
ID | Person ID | School ID | Start Date | End Date
1  | 1         | 1         | 2005       | 2015
2  | 1         | 5         | 2015       | 2019

Query: "Which schools did Ram attend?"
SELECT s.school_name, ps.start_date, ps.end_date
FROM Person_School ps
JOIN School s ON ps.school_id = s.school_id
WHERE ps.person_id = 1;

Result:
- Budhanilkantha School (2005-2015)
- Tribhuvan University (2015-2019)
```

**Same concept for employment history!**

---

### 3. Database Views

**Problem**: Complex queries are long and repetitive

**Solution**: Pre-built Views

**Example: vw_person_education**
```sql
CREATE VIEW vw_person_education AS
SELECT 
    p.id AS person_id,
    p.name AS person_name,
    s.school_name,
    ps.start_date,
    ps.end_date,
    ps.notes,
    TIMESTAMPDIFF(YEAR, ps.start_date, 
      COALESCE(ps.end_date, CURDATE())) AS years_attended
FROM Person p
JOIN Person_School ps ON p.id = ps.person_id
JOIN School s ON ps.school_id = s.school_id;
```

**Usage:**
```sql
-- Instead of complex JOIN query, just:
SELECT * FROM vw_person_education WHERE person_id = 1;
```

---

### 4. Stored Procedures

**Problem**: Need complete person profile in multiple places

**Solution**: Stored Procedure

```sql
CALL sp_get_person_profile(1);

-- Returns 4 result sets:
-- 1. Basic person info
-- 2. All contact numbers
-- 3. All education history
-- 4. All employment history
```

One call → Complete profile!

---

### 5. Triggers

**Problem**: Need to log when persons are created/updated

**Solution**: Automatic Triggers

```sql
-- Trigger fires automatically when INSERT happens
CREATE TRIGGER tr_person_created
AFTER INSERT ON Person
FOR EACH ROW
BEGIN
    INSERT INTO Data_logs (log_text, log_code_string, status_code)
    VALUES (
        CONCAT('New person created: ', NEW.name),
        'PERSON_CREATE',
        201
    );
END;

-- No manual logging needed!
-- System logs automatically.
```

---

### 6. Security Measures

**Password Security:**
```
Plain password: "mypassword123"
      ↓
bcrypt.hash() with salt (10 rounds)
      ↓
Stored: "$2a$10$8K1p/a0dL3LVOBDJqYKYWe..."
      ↓
Cannot be reversed! One-way encryption

Login check:
bcrypt.compare("mypassword123", stored_hash)
→ Returns true/false
```

**SQL Injection Prevention:**
```javascript
// ❌ UNSAFE - Don't do this!
const query = `SELECT * FROM Person WHERE name = '${userInput}'`;
// If userInput = "'; DROP TABLE Person; --"
// → Deletes entire table!

// ✅ SAFE - We do this!
const query = `SELECT * FROM Person WHERE name = ?`;
const params = [userInput];
// MySQL automatically escapes dangerous characters
```

**Role-Based Access:**
```javascript
// Middleware checks role before allowing action
function authorizeRoles(...allowedRoles) {
    if (!allowedRoles.includes(user.role)) {
        return 403 Forbidden;
    }
    proceed();
}

// Usage:
router.delete('/persons/:id', 
    authenticateToken,           // Must be logged in
    authorizeRoles('admin'),     // Must be admin
    deletePerson                 // Then execute
);
```

---

## How to Use This System

### For Developers:

#### Setup (First Time)
```bash
# 1. Extract ZIP file
unzip person-tracking-backend.zip

# 2. Navigate to project
cd person-tracking-backend

# 3. Install dependencies
npm install

# 4. Configure database
cp .env.example .env
# Edit .env with your MySQL credentials

# 5. Create database
mysql -u root -p < database/schema.sql

# 6. Start server
npm start
```

#### Testing APIs
```bash
# Method 1: Using cURL
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@system.com","password":"admin123"}'

# Method 2: Using Postman
# - Import endpoints
# - Set Authorization header
# - Test each endpoint

# Method 3: Using Thunder Client (VS Code Extension)
# - Create requests
# - Test inline in VS Code
```

#### Adding New Features
```
Example: Add "References" feature

1. Database:
   CREATE TABLE Person_References (
       id INT PRIMARY KEY,
       person_id INT,
       reference_name VARCHAR(100),
       reference_contact VARCHAR(15),
       relationship VARCHAR(50)
   );

2. Controller (controllers/referenceController.js):
   - addReference()
   - getReferencesByPerson()
   - updateReference()
   - deleteReference()

3. Routes (routes/referenceRoutes.js):
   - POST /api/references
   - GET /api/references/person/:id
   - PUT /api/references/:id
   - DELETE /api/references/:id

4. Server (server.js):
   app.use('/api/references', referenceRoutes);

5. Test!
```

---

### For End Users:

#### HR Staff Workflow:
```
Daily Tasks:

Morning:
1. Login to system
2. Check new person requests
3. Create person records

Afternoon:
4. Add education history
5. Add employment history
6. Add contact numbers

Evening:
7. Review completed profiles
8. Send to verifier
```

#### Verifier Workflow:
```
Daily Tasks:

1. Login as verifier
2. View persons list
3. Select person to verify
4. Review education claims
5. Call schools to verify
6. Review employment claims
7. Call companies to verify
8. Add verification notes
9. Mark as verified
```

#### Admin Workflow:
```
Weekly Tasks:

1. Monitor system statistics
2. Review user activity logs
3. Create new users (HR, Verifiers)
4. Add new organizations (schools, companies)
5. Generate reports
6. Backup database
```

---

## Benefits of This System

### 1. **Centralized Data**
- ❌ Before: Papers everywhere, Excel files, emails
- ✅ After: Everything in one database

### 2. **Complete History**
- ❌ Before: Only know current job
- ✅ After: See entire career path

### 3. **Easy Verification**
- ❌ Before: Call each school/company manually
- ✅ After: All info in system, quick lookups

### 4. **Powerful Queries**
- ❌ Before: "Find all TU graduates" → manually check files
- ✅ After: One database query → instant results

### 5. **Security & Accountability**
- ❌ Before: Anyone can edit files
- ✅ After: Role-based access, activity logs

### 6. **Scalability**
- ❌ Before: 100 persons → 100 folders
- ✅ After: 10,000 persons → same system

---

## Common Questions & Answers

**Q: What if someone studied at 5 schools?**
A: Add 5 records in Person_School table. No limit!

**Q: Can we track part-time jobs?**
A: Yes! Add multiple employment records with overlapping dates.

**Q: What if someone has no education history?**
A: That's fine. Education history is optional.

**Q: Can we delete a person?**
A: Yes, but only admin can. It cascades (deletes all related records automatically).

**Q: How do we know who created a person?**
A: Check Data_logs table for audit trail.

**Q: What if we need to add more fields?**
A: Easy! ALTER TABLE Person ADD COLUMN new_field VARCHAR(100);

**Q: Can we export data?**
A: Yes, query database and export to CSV/Excel.

**Q: Is this production-ready?**
A: Yes! Has authentication, validation, error handling, logging.

**Q: Can we add photos?**
A: Yes! Extend with file upload for person photos/documents.

**Q: What about data privacy?**
A: Implement encryption, access controls, and comply with local data protection laws.

---

## Future Enhancements

**Short-term (Easy):**
1. Email notifications
2. Export to PDF/Excel
3. Advanced search filters
4. Dashboard with charts
5. Profile photos

**Medium-term (Moderate):**
1. Frontend web application
2. Mobile app
3. Document upload (certificates, IDs)
4. OCR to extract data from documents
5. Two-factor authentication

**Long-term (Complex):**
1. AI to detect fake documents
2. Blockchain for tamper-proof records
3. Integration with government databases
4. Biometric verification
5. Real-time sync across devices

---

## Conclusion

The **Person Tracking System** is a comprehensive, production-ready backend solution for tracking individuals and their complete life history. It demonstrates:

✅ **Complete CRUD Operations** on all entities  
✅ **Complex Database Relationships** (one-to-many, many-to-many)  
✅ **Authentication & Authorization** with JWT and role-based access  
✅ **Advanced SQL** (views, procedures, functions, triggers)  
✅ **RESTful API Design** following industry standards  
✅ **Security Best Practices** (password hashing, SQL injection prevention)  
✅ **Activity Logging** for complete audit trail  
✅ **Scalability** to handle thousands of records  
✅ **Professional Code** with proper error handling  
✅ **Complete Documentation** for easy understanding  

Perfect for college projects, government systems, HR departments, or any application requiring person tracking with historical data!

---

**System Version:** 1.0  
**Last Updated:** February 2026  
**Database:** MySQL 5.7+  
**Backend:** Node.js + Express  
**API Style:** RESTful  

---

**Made with ❤️ for learning and development**
